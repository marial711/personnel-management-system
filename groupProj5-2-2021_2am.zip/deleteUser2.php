<!--	Names: 	 Brian Hafey, Jacob Kalat, Maria Leyva
      	Date: 	 5/2/2021
      	Purpose: To delete data from the search results with the checkboxes-->

<!-- Declares style for table -->
<style>
    table{
        background-color:#DDEEFF;
        border:1px solid black;
        padding: 3px;
    }
	th{
		background-color:#DDEEFF;
        border:1px solid black;
        padding: 3px;
	}
	tr{
		background-color:#DDEEFF;
        border:1px solid black;
        padding: 3px;
	}
	td{
		background-color:#DDEEFF;
        border:1px solid black;
        padding: 3px;
	}
</style>

<?php
	
	$deletion = $_POST["deletion"];
	echo "Deleting data: '$deletion'";
	$deleteQuery = "DELETE FROM personnelInfo WHERE id='$deletion'";
	$action = mysqli_query($link,$query);
	
	if ($link->query($deleteQuery) === TRUE)
	{
		echo "record deleted!";
	}
	else
	{
		echo "Error! Abort! " . $link->error;
	}
	
	
	//Print the current state of the table
	echo "<table><tr><th>Full Name</th><th>Photos</th><th>Date Joined</th><th>Department</th><th>Project Involved</th><th>Annual Salary</th></tr>";
    if(numOfRows >= 0)
    {
        while($info = mysqli_fetch_assoc($sth))
        {
            echo "<tr>";
            foreach($info as $key=>$value)
            {
                if($key == 'image')
                {
                    echo "<td>";
                    echo '<img src="data:image/jpeg;base64,'.base64_encode($value).'" height="200" width="200"/>';
                    echo "</td>";
                }
                elseif($key != 'No')
                {
                    echo "<td>$value</td>";
                }
            }
            echo "</tr>";
        }
    }
echo "</table>";
	
	mysqli_close($link);
	//The Following is excess notes which are pretty much garbage leftovers
	
	
	//Deletes user from database as specified in the field entry
	/*
	echo "<a href='index.html'>Back to Home</a>";
	//Collect data from post
	$link = mysqli_connect("localhost:3306", "root", "root", "project") or die('cannot connect to the requested database');
	$db = mysqli_select_db($link, "project");
	
	if(isset($_POST['submit']))
	{
		$toDelete = $_POST["deletion"];
		$query = "DELETE * FROM personnelInfo WHERE id=$toDelete";
		$query_run = mysqli_query($link, $query);
		$pick = "SELECT * FROM personnelInfo WHERE id=1";
		echo $pick;
	}*/
	/*
	$toDelete = $_POST["deletion"];
	$selection = "SELECT $deletion FROM personnelInfo";
	$sqlDelete = "DELETE $selection FROM personnelInfo"; //WHERE id=3
	
	if (mysqli_query($link, $sqlDelete)){
		echo "Deleted requested record."
	}
	else {
		echo "Could not delete record. Error: " . mysqli_error($link);
	}
	
	*/
	// Close our MySQL Link
    
	
	
/*
	$query = "SELECT * from personnelInfo";
	$result = mysqli_query($link, $query);
	$numRows = mysqli_num_rows($result);
	
	echo "<table style='border: 1px solid black;'>";
	
	echo 
	"<tr><th>No.</th>
	<th>Full Name</th>
	<th>Phone</th>
	<th>E-mail</th>
	</tr>”;
	
	if($numOfrows > 0)
	{
	while($info = mysqli_fetch_array($result, MYSQLI_ASSOC))  //mysqli_fetch_assoc(), mysqli_fetch_row()
	{
		print_r($info);
		echo "<tr style='border: 1px solid black;'>”;
		foreach($info as $field)
		{
			echo "<td style='border: 1px solid black;'>$field</td>";
		}
			echo "</tr>";
		}
	}
	
	echo "</table>”;

	*/
?>