create table tbl_images
(id tinyint(3) unsigned NOT NULL auto_increment,
 image blob NOT NULL,
 PRIMARY KEY(id));

